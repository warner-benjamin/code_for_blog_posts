## fastai docs

This is the source of the documentation for [fastai](https://docs.fast.ai). It is generated with nbdev from the fastai repo. Don't edit things here directly.

